﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using ConverterApp.Models;


namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Get the location of the user's Desktop
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            //Build a image file path from the original image path
            FileInfo fileinfo = new FileInfo($"{desktopPath}\\myimage.jpg");

            //Provide an Image from a file on your Desktop
            Image image = Image.FromFile(fileinfo.FullName);

            //Convert Image to Base64 encoded text
            string base64image = Converter.ImageToBase64(image, ImageFormat.Jpeg);

            //Output the Base64 encoded text
            Console.WriteLine(base64image);
        }
    }
}
